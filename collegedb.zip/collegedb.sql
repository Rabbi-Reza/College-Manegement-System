-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 28, 2017 at 05:23 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `collegedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `ID` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `writter` varchar(50) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `quantity` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`ID`, `name`, `writter`, `subject`, `quantity`) VALUES
(1, 'Physics part 1', 'Tofajjol', 'physics', '5'),
(2, 'Chemistry part 2', 'Hazari', 'Chemistry', '7');

-- --------------------------------------------------------

--
-- Table structure for table `c1f`
--

CREATE TABLE IF NOT EXISTS `c1f` (
  `ID` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `grade` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c1f`
--

INSERT INTO `c1f` (`ID`, `roll`, `grade`) VALUES
(1, '3', '2');

-- --------------------------------------------------------

--
-- Table structure for table `c1h`
--

CREATE TABLE IF NOT EXISTS `c1h` (
  `ID` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c1h`
--

INSERT INTO `c1h` (`ID`, `roll`, `grade`) VALUES
(1, '2', '23 '),
(2, '3', '43');

-- --------------------------------------------------------

--
-- Table structure for table `c2f`
--

CREATE TABLE IF NOT EXISTS `c2f` (
  `ID` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c2f`
--

INSERT INTO `c2f` (`ID`, `roll`, `grade`) VALUES
(1, '2312', '21'),
(2, '213', '232');

-- --------------------------------------------------------

--
-- Table structure for table `c2h`
--

CREATE TABLE IF NOT EXISTS `c2h` (
  `ID` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c2h`
--

INSERT INTO `c2h` (`ID`, `roll`, `grade`) VALUES
(1, '231', '32'),
(2, '43', '23');

-- --------------------------------------------------------

--
-- Table structure for table `ec1f`
--

CREATE TABLE IF NOT EXISTS `ec1f` (
  `ID` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ec1h`
--

CREATE TABLE IF NOT EXISTS `ec1h` (
  `ID` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ec2f`
--

CREATE TABLE IF NOT EXISTS `ec2f` (
  `ID` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ec2h`
--

CREATE TABLE IF NOT EXISTS `ec2h` (
  `ID` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `es1f`
--

CREATE TABLE IF NOT EXISTS `es1f` (
  `ID` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `es1h`
--

CREATE TABLE IF NOT EXISTS `es1h` (
  `ID` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `es2f`
--

CREATE TABLE IF NOT EXISTS `es2f` (
  `ID` int(10) NOT NULL,
  `sub` int(50) NOT NULL,
  `date` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `es2h`
--

CREATE TABLE IF NOT EXISTS `es2h` (
  `ID` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logadmin`
--

CREATE TABLE IF NOT EXISTS `logadmin` (
  `ID` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logadmin`
--

INSERT INTO `logadmin` (`ID`, `username`, `password`) VALUES
(1, 'nirzhor', 'nirzhor'),
(2, 'pritom', 'pritom'),
(3, 'a', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `rout`
--

CREATE TABLE IF NOT EXISTS `rout` (
  `ID` int(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `1st` varchar(50) NOT NULL,
  `2nd` varchar(50) NOT NULL,
  `bk` varchar(50) NOT NULL,
  `3rd` varchar(50) NOT NULL,
  `4th` varchar(50) NOT NULL,
  `5th` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rout`
--

INSERT INTO `rout` (`ID`, `date`, `1st`, `2nd`, `bk`, `3rd`, `4th`, `5th`) VALUES
(1, 'Saturday', 'Physics-ABC', '----', 'Break', 'Chemistry-cdf', 'Math-xyz', '----'),
(2, 'Sunday', '-----', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', '-----'),
(3, 'Monday', '---------', '------------', 'break', 'dfgdsged', 'erfeafde', 'efafvaefvea'),
(4, 'Tuesday', 'efegvf', 'efvfaf', 'Break', '--------', 'sfvdfdf', 'faefveava'),
(5, 'Wednesday', 'efegvf', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', 'efafvaefvea'),
(6, 'Thursday', '-----', 'Bangla -asd', 'Break', 'Chemistry-cdf', 'eaaeff', '----');

-- --------------------------------------------------------

--
-- Table structure for table `routc1`
--

CREATE TABLE IF NOT EXISTS `routc1` (
  `ID` int(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `1st` varchar(50) NOT NULL,
  `2nd` varchar(50) NOT NULL,
  `bk` varchar(50) NOT NULL,
  `3rd` varchar(50) NOT NULL,
  `4th` varchar(50) NOT NULL,
  `5th` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routc1`
--

INSERT INTO `routc1` (`ID`, `date`, `1st`, `2nd`, `bk`, `3rd`, `4th`, `5th`) VALUES
(1, 'Saturday', 'Physics-ABC', '----', 'Break', 'Chemistry-cdf', 'Math-xyz', '----'),
(2, 'Sunday', '-----', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', '-----'),
(3, 'Monday', '---------', '------------', 'break', 'dfgdsged', 'erfeafde', 'efafvaefvea'),
(4, 'Tuesday', 'efegvf', 'efvfaf', 'Break', '--------', 'sfvdfdf', 'faefveava'),
(5, 'Wednesday', 'efegvf', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', 'efafvaefvea'),
(6, 'Thursday', '-----', 'Bangla -asd', 'Break', 'Chemistry-cdf', 'eaaeff', '----');

-- --------------------------------------------------------

--
-- Table structure for table `routc2`
--

CREATE TABLE IF NOT EXISTS `routc2` (
  `ID` int(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `1st` varchar(50) NOT NULL,
  `2nd` varchar(50) NOT NULL,
  `bk` varchar(50) NOT NULL,
  `3rd` varchar(50) NOT NULL,
  `4th` varchar(50) NOT NULL,
  `5th` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routc2`
--

INSERT INTO `routc2` (`ID`, `date`, `1st`, `2nd`, `bk`, `3rd`, `4th`, `5th`) VALUES
(1, 'Saturday', 'Physics-ABC', '----', 'Break', 'Chemistry-cdf', 'Math-xyz', '----'),
(2, 'Sunday', '-----', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', '-----'),
(3, 'Monday', '---------', '------------', 'break', 'dfgdsged', 'erfeafde', 'efafvaefvea'),
(4, 'Tuesday', 'efegvf', 'efvfaf', 'Break', '--------', 'sfvdfdf', 'faefveava'),
(5, 'Wednesday', 'efegvf', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', 'efafvaefvea'),
(6, 'Thursday', '-----', 'Bangla -asd', 'Break', 'Chemistry-cdf', 'eaaeff', '----');

-- --------------------------------------------------------

--
-- Table structure for table `routs1`
--

CREATE TABLE IF NOT EXISTS `routs1` (
  `ID` int(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `1st` varchar(50) NOT NULL,
  `2nd` varchar(50) NOT NULL,
  `bk` varchar(50) NOT NULL,
  `3rd` varchar(50) NOT NULL,
  `4th` varchar(50) NOT NULL,
  `5th` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routs1`
--

INSERT INTO `routs1` (`ID`, `date`, `1st`, `2nd`, `bk`, `3rd`, `4th`, `5th`) VALUES
(1, 'Saturday', 'Physics-ABC', '----', 'Break', 'Chemistry-cdf', 'Math-xyz', '----'),
(2, 'Sunday', '-----', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', '-----'),
(3, 'Monday', '---------', '------------', 'break', 'dfgdsged', 'erfeafde', 'efafvaefvea'),
(4, 'Tuesday', 'efegvf', 'efvfaf', 'Break', '--------', 'sfvdfdf', 'faefveava'),
(5, 'Wednesday', 'efegvf', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', 'efafvaefvea'),
(6, 'Thursday', '-----', 'Bangla -asd', 'Break', 'Chemistry-cdf', 'eaaeff', '----');

-- --------------------------------------------------------

--
-- Table structure for table `routs2`
--

CREATE TABLE IF NOT EXISTS `routs2` (
  `ID` int(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `1st` varchar(50) NOT NULL,
  `2nd` varchar(50) NOT NULL,
  `bk` varchar(50) NOT NULL,
  `3rd` varchar(50) NOT NULL,
  `4th` varchar(50) NOT NULL,
  `5th` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `routs2`
--

INSERT INTO `routs2` (`ID`, `date`, `1st`, `2nd`, `bk`, `3rd`, `4th`, `5th`) VALUES
(1, 'Saturday', 'Physics-ABC', '----', 'Break', 'Chemistry-cdf', 'Math-xyz', '----'),
(2, 'Sunday', '-----', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', '-----'),
(3, 'Monday', '---------', '------------', 'break', 'dfgdsged', 'erfeafde', 'efafvaefvea'),
(4, 'Tuesday', 'efegvf', 'efvfaf', 'Break', '--------', 'sfvdfdf', 'faefveava'),
(5, 'Wednesday', 'efegvf', 'Bangla -asd', 'Break', 'adsfkag', 'eaaeff', 'efafvaefvea'),
(6, 'Thursday', '-----', 'Bangla -asd', 'Break', 'Chemistry-cdf', 'eaaeff', '----');

-- --------------------------------------------------------

--
-- Table structure for table `s1f`
--

CREATE TABLE IF NOT EXISTS `s1f` (
  `ID` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s1f`
--

INSERT INTO `s1f` (`ID`, `roll`, `grade`) VALUES
(1, '1', '3'),
(2, '4', '2.5');

-- --------------------------------------------------------

--
-- Table structure for table `s1h`
--

CREATE TABLE IF NOT EXISTS `s1h` (
  `ID` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s1h`
--

INSERT INTO `s1h` (`ID`, `roll`, `grade`) VALUES
(1, '5', '2'),
(2, '7', '2');

-- --------------------------------------------------------

--
-- Table structure for table `s2f`
--

CREATE TABLE IF NOT EXISTS `s2f` (
  `ID` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s2f`
--

INSERT INTO `s2f` (`ID`, `roll`, `grade`) VALUES
(1, '78', '5'),
(2, '34', '2.5');

-- --------------------------------------------------------

--
-- Table structure for table `s2h`
--

CREATE TABLE IF NOT EXISTS `s2h` (
  `ID` int(10) NOT NULL,
  `roll` varchar(10) NOT NULL,
  `grade` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `s2h`
--

INSERT INTO `s2h` (`ID`, `roll`, `grade`) VALUES
(1, '23', '4'),
(2, '12', '3');

-- --------------------------------------------------------

--
-- Table structure for table `staffs`
--

CREATE TABLE IF NOT EXISTS `staffs` (
  `ID` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffs`
--

INSERT INTO `staffs` (`ID`, `name`, `dept`, `phone`) VALUES
(1, 'md. Mostofa', 'physics', '012474364356');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `ID` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `dept` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`ID`, `name`, `designation`, `dept`, `phone`, `email`) VALUES
(2, 'Shakhawat Hossain', ' professor', 'Mathematics', '0123fsdfvsd4846', 'gsgsfsdfsg@asffv.com'),
(3, 'Tariqul haq', 'Asst-Professior', 'English', '974123', 'srdgsaudfsafy');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
